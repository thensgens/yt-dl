from flask_appconfig.cmd import main_flaskdev

if __name__ == '__main__':
    main_flaskdev()
