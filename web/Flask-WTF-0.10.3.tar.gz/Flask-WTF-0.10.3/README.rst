Flask-WTF
=========

.. image:: https://badge.fury.io/py/Flask-WTF.png
    :target: http://badge.fury.io/py/Flask-WTF
.. image:: https://travis-ci.org/lepture/flask-wtf.png?branch=master
    :target: https://travis-ci.org/lepture/flask-wtf
.. image:: https://coveralls.io/repos/lepture/flask-wtf/badge.png?branch=master
    :target: https://coveralls.io/r/lepture/flask-wtf

Simple integration of Flask and WTForms, including CSRF, file upload
and Recaptcha integration.

For more information please refer to the online docs:

https://flask-wtf.readthedocs.org
